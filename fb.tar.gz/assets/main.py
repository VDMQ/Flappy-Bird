import asyncio
import random
import pygame
import sys
is_web = sys.platform == "emscripten"


pygame.init()

if is_web:
    import asyncio, js
    async def go_fullscreen():
        await asyncio.sleep(0.5)  # wait for canvas setup
        js.document.querySelector("canvas").requestFullscreen()
    asyncio.ensure_future(go_fullscreen())

#pygame.mixer.init()  # Initialize mixer for sounds
#pygame.mixer.init()
pygame.display.set_caption("Voidox - Threshing Skully")
#hb_m = pygame.mixer.Sound('Hb.mp3')
#hb_m.set_volume(0.2)
#pygame.mixer.music.load('Silent_Solitude.mp3')
#pygame.mixer.music.set_volume(0.05)
record = 0
start_time = 0
#hb_m.play(-1)
win_x = 450
win_y = 850
async def main():
    global win_x
    global win_y
    global start_time
    global record
    global current_time
    screen = pygame.display.set_mode((win_x,win_y), pygame.RESIZABLE)
    clock = pygame.time.Clock()
    game_active = False
    playerG = 0
    status = "alive"
    current_time = 0
    count = 0
    text_font = pygame.font.SysFont("Arial", 30)
    times = text_font.render(f'Score: {current_time}',False,(64,64,64))
    times_rect = times.get_rect(topleft = (0,0))
    record_times = text_font.render(f'Highest score: {round(record/1000,2)}s',False,(0,255,0))
    record_times_rect = record_times.get_rect(topleft = (3,0))
    background = pygame.image.load("big_bg.png").convert_alpha()
    user = pygame.image.load("Skully.png").convert_alpha()
    user_rect = user.get_rect(center = (136,200))
    starterimg = pygame.transform.scale(user,(128,128))
    starterimg1 = pygame.transform.rotate(starterimg, count)
    starterimg_rect = starterimg1.get_rect(center = (win_x/2,win_y/2))
    pipe = pygame.image.load("Pipe.png").convert_alpha()
    pipe_rect = pipe.get_rect(midtop = (-350,400))
    pipe2 = pygame.transform.rotate(pipe,180)
    pipe_rect2 = pipe2.get_rect(midbottom = (-350,200))
    grd = pygame.image.load("Ground.png").convert_alpha()
    grd1 = pygame.transform.scale(grd,(1920,25))
    grd_rect = grd1.get_rect(topleft = (0,825))
    overview0 = text_font.render("Click to play", False, (255,0,0))
    overview_rect0 = overview0.get_rect(center = (win_x/2,win_y/2 + 150))
    overview = text_font.render("Game Over", False, (255,0,0))
    overview_rect = overview.get_rect(center = (win_x/2,win_y/2))
    overview2 = text_font.render("Click to menu", False, (255,0,0))
    overview_rect2 = overview2.get_rect(center = (win_x/2,win_y/2 + 50))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if game_active:
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    playerG = -10
            else:
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    if status == "alive":
                        start_time = pygame.time.get_ticks()
                        #pygame.mixer.music.play()
                        game_active = True
                    else:
                        game_active = True
                        await main()
        check = pygame.display.get_window_size()
        if check != (win_x,win_y):
            win_x,win_y = check
        if game_active:
            current_time = pygame.time.get_ticks() - start_time
            times = text_font.render(f'Score: {round(current_time/1000,2)}s',False,(255, 0, 0))
            times_rect = times.get_rect(topleft = (3,0))

            pipe_rect.x -= 3.5
            pipe_rect2.x -= 3.5
            if pipe_rect.x <= -150:
                pipe_rect.left = 450
                rnd = random.randint(250, 775)
                pipe_rect.y = rnd
                pipe_rect2.left = 450
                pipe_rect2.y = rnd - 750 - 175
            if user_rect.colliderect(pipe_rect):
                game_active = False
                status = "dead"
                if current_time > record:
                    record = current_time
            playerG += 0.5
            user_rect.y += playerG
            if user_rect.colliderect(pipe_rect2):
                game_active = False
                status = "dead"
                if current_time > record:
                    record = current_time
            if win_y >= 750:
                grd_rect = grd1.get_rect(topleft = (0,825))
                if user_rect.y > grd_rect.y-50:
                    game_active = False
                    status = "dead"
                    if current_time > record:
                        record = current_time
            else:
                grd_rect = grd1.get_rect(topleft = (0,win_y-25))
                if user_rect.y > grd_rect.y-50:
                    game_active = False
                    status = "dead"
                    if current_time > record:
                        record = current_time
            if user_rect.y < 0:
                user_rect.y = 0
            screen.blit(background,(0,0))
            screen.blit(user,user_rect)
            screen.blit(pipe,pipe_rect)
            screen.blit(pipe2,pipe_rect2)
            screen.blit(grd1,grd_rect)
            screen.blit(times,times_rect)
        else:
            if status == "alive":
                count -= 1
                starterimg1 = pygame.transform.rotate(starterimg, count)
                starterimg_rect = starterimg1.get_rect(center = (win_x/2,win_y/2))
                overview_rect0 = overview0.get_rect(center = (win_x/2,win_y/2 + 150))
                screen.blit(background,(0,0))
                screen.blit(grd1,grd_rect)
                screen.blit(starterimg1,starterimg_rect)
                screen.blit(overview0,overview_rect0)
                screen.blit(record_times,record_times_rect)
                #pygame.mixer.music.stop()
            else:
                overview_rect = overview.get_rect(center = (win_x/2,win_y/2))
                overview_rect2 = overview2.get_rect(center = (win_x/2,win_y/2 + 50))
                screen.blit(background,(0,0))
                screen.blit(user,user_rect)
                screen.blit(pipe,pipe_rect)
                screen.blit(pipe2,pipe_rect2)
                screen.blit(grd1,grd_rect)
                screen.blit(times,times_rect)
                screen.blit(overview,overview_rect)
                screen.blit(overview2,overview_rect2)
        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)

try:
    import pygame._sdl2.video as video
    video.set_
except Exception:
    pass

asyncio.run(main())